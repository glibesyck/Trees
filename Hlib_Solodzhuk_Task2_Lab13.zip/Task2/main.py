"""
Main module for demonstrating time difference between finding elements using 
different approaches.
CAUTION!!! It may take around hour of your life:))))
"""
from linkedbst import LinkedBST

if __name__ == '__main__':
    tree = LinkedBST()
    tree.demo_bst('words.txt')